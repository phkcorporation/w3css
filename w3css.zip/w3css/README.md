# w3css

Load either w3.css (version 3 or 4), w3mobile.css, or w3pro.css automatically in the header 

# About W3.CSS

W3.CSS is a modern CSS framework with built-in responsiveness:

    Smaller and faster than any other CSS frameworks.
    Easier to learn, and easier to use than any other CSS frameworks.
    Better cross-browser compatibility than any other CSS frameworks.
    Uses standard CSS only (No jQuery or JavaScript library).
    Supports modern responsive mobile first design by default.
	Provides CSS equality for all browsers: Chrome, Firefox, Edge, IE, Safari, Opera, ...
    Provides CSS equality for all devices: desktop, laptop, tablet, and mobile.
    Speeds up and simplifies web development: 


